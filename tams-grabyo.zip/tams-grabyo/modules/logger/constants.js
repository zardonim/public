var config = {};

config.logger = {};
config.logger.logLevel = 'debug';

module.exports = config;