module.exports = (function () {

    const winston = require('winston');
    const contants = require('./constants');

    function create(logLevel) {
        return init(logLevel);
    }

    function init(logLevel) {
        var _logger;
        var _logLevel;

        if (logLevel != null) {
            _logLevel = logLevel;
        } else {
            _logLevel = contants.logger.logLevel;
        }
        _logger = winston.createLogger({
            level: _logLevel,
            format: winston.format.combine(
                winston.format.colorize(),
                winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss.SSS' }),
                winston.format.printf(function ({ timestamp, level, message }) {
                    return '' + timestamp + ' ' + level + ' ' + message
                })
            ),
            transports: [new winston.transports.Console()]
        });


        function _log() {
            if (!arguments || arguments.length === 0) {
                return;
            }

            var args = Array.from(arguments);

            var logLevel = args[0];
            if (logLevel == null || (typeof logLevel !== 'string')) {
                logLevel = 'none';
            } else {
                logLevel = logLevel.toLowerCase();
            }

            if (!winston.config.npm.levels.hasOwnProperty(logLevel)) {
                logLevel = 'info';
            } else {
                args.shift();
            }

            var statement = '';
            var jsonStatement = {
                timestamp: '',
                level: logLevel.toLowerCase(),
                message: ''
            };

            for (var i = 0; i < args.length; i++) {
                if (typeof args[i] === 'object' && args[i] !== null) {
                    statement += ' ' + JSON.stringify(args[i]);
                } else {
                    statement += ' ' + args[i];
                }
            }

            var date = new Date();
            jsonStatement['timestamp'] = date.toISOString().replace('T', ' ');
            jsonStatement['timestamp'] = jsonStatement['timestamp'].replace('Z', '');
            jsonStatement['timestamp'] = jsonStatement['timestamp'] + ' +00:00';
            jsonStatement['message'] = statement.trim();

            jsonStatement['message'] = ' [*] ' + jsonStatement['message'];
            _logger.log(jsonStatement);
        }

        return {
            log: _log
        }
    }

    return {
        create: create
    };

})();