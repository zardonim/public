var config = {};

config.stream = {};
config.stream.observingStatusMilliseconds = 1500;

module.exports = config;