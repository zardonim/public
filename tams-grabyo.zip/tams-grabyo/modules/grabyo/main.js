module.exports = (function () {

    const utilities = require('../common/utilities');
    const constants = require('./constants');
    const EventEmitter = require('events');
    const { randomUUID } = require('crypto');

    function create(logger) {
        return init(logger);
    }

    function init(logger) {
        var _logger;
        if (logger != null) {
            _logger = logger;
        } else {
            _logger = {
                log: console.log
            };
        }
        
        var _instanceId = randomUUID();
        var _grabyoToken;
        var _grabyoUrl = 'https://oapi.grabyo.com';
        var _grabyoEndpoint = _setGrabyoEndpoint();
        var _streamId = '';
        var _streamStatus = 'offline';
        var _eventEmitter = new EventEmitter();
        var _streamStatusUpdateInterval = null;

        function _setGrabyoToken(token) {
            _grabyoToken = token;
            _observeStreamStatusUpdate();
            _logger.log('Grabyo interface', _instanceId, 'properly instantiated!');
        }

        function _setGrabyoUrl(url) {
            _grabyoUrl = url;
            _grabyoEndpoint = _setGrabyoEndpoint();
        }

        function _getGrabyoUrl() {
            return _grabyoUrl;
        }

        function _setStreamId(streamId) {
            _streamId = streamId;
        }

        function _getStreamId() {
            return _streamId;
        }

        function _setGrabyoEndpoint() {
            var grabyoEndpoint = {};
            grabyoEndpoint['protocol'] = _grabyoUrl.split('://')[0];
            grabyoEndpoint['hostname'] = _grabyoUrl.replace(grabyoEndpoint['protocol'] + '://', '').split('/')[0];
            grabyoEndpoint['hostname'] = grabyoEndpoint['hostname'].split(':')[0];
            grabyoEndpoint['port'] = grabyoEndpoint['hostname'].split(':')[1];
            if (grabyoEndpoint['port'] == null) {
                switch (grabyoEndpoint['protocol']) {
                    case 'http':
                        grabyoEndpoint['port'] = 80;
                        break;
                    case 'https':
                        grabyoEndpoint['port'] = 443;
                        break;
                }
            }
            return grabyoEndpoint;
        }


        function _getStreamStatus() {
            return utilities.performRequest({
                method: 'GET',
                path: '/v1/streams/' + _streamId,
                hostname: _grabyoEndpoint['hostname'],
                port: _grabyoEndpoint['port'],
                protocol: _grabyoEndpoint['protocol'],
                headers: { 'x-api-key': _grabyoToken }
            });
        }

        async function _setStreamSource(source, skipHealthCheck) {
            try {
                var body = {};
                if (skipHealthCheck == null) {
                    body['skipSourceHealthcheck'] = true;
                }
                body['source'] = 'url:' + source;

                var status = await utilities.performRequest({
                    method: 'PUT',
                    path: '/v1/streams/' + _streamId + '/source',
                    body: body,
                    hostname: _grabyoEndpoint['hostname'],
                    port: _grabyoEndpoint['port'],
                    protocol: _grabyoEndpoint['protocol'],
                    headers: { 'x-api-key': _grabyoToken, 'Content-Type': 'application/json' }
                });

                var sourceRes = status['source'];
                if (sourceRes == null) {
                    return false;
                } else {
                    return (sourceRes.replace('url:', '') === source);
                }
            } catch (err) {
                _logger.log('ERROR', 'An error occurred!', err);
                return;
            }
        }

        function _enableStream() {
            _logger.log('DEBUG', 'Request stream', _streamId, 'starting...');
            return utilities.performRequest({
                method: 'PATCH',
                path: '/v1/streams/' + _streamId + '/status/online',
                hostname: _grabyoEndpoint['hostname'],
                port: _grabyoEndpoint['port'],
                protocol: _grabyoEndpoint['protocol'],
                headers: { 'x-api-key': _grabyoToken }
            });

        }

        function _disableStream() {
            _logger.log('DEBUG', 'Request stream', _streamId, 'stopping...');
            return utilities.performRequest({
                method: 'PATCH',
                path: '/v1/streams/' + _streamId + '/status/offline',
                hostname: _grabyoEndpoint['hostname'],
                port: _grabyoEndpoint['port'],
                protocol: _grabyoEndpoint['protocol'],
                headers: { 'x-api-key': _grabyoToken }
            });
        }

        function _getEventEmitter() {
            return _eventEmitter;
        }

        function _getInstanceId() {
            return _instanceId;
        }

        async function _observeStreamStatusUpdate() {
            try {
                var status = await _getStreamStatus();
                status = status['streamStatus'];
                if (status != null && status.toUpperCase() !== _streamStatus.toUpperCase()) {
                    _logger.log('DEBUG', 'The stream status', _streamId, 'is changed from', _streamStatus.toUpperCase(), 'to', status.toUpperCase(), '!');
                    _eventEmitter.emit('streamStatusChanged', status);
                    _streamStatus = status;
                }
            } catch (err) {
                _logger.log('ERROR', 'An error occurred in observing stream status!', err);
            }
            if (_streamStatusUpdateInterval != null) {
                clearTimeout(_streamStatusUpdateInterval);
            }
            _streamStatusUpdateInterval = setTimeout(async function () {
                await _observeStreamStatusUpdate();
            }, constants.stream.observingStatusMilliseconds);
        }

        return {
            setToken: _setGrabyoToken,
            setUrl: _setGrabyoUrl,
            getUrl: _getGrabyoUrl,
            setStreamId: _setStreamId,
            getStreamId: _getStreamId,
            getStreamStatus: _getStreamStatus,
            getObserver: _getEventEmitter,
            setStreamSource: _setStreamSource,
            startRecording: _enableStream,
            stopRecording: _disableStream,
            getId: _getInstanceId
        };
    }

    return {
        getInstance: create
    };

})();