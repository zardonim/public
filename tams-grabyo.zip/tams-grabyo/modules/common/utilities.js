module.exports = (function () {

    const _connectivity = { http: require('http'), https: require('https') };

    function performRequest({ method = 'GET', protocol = 'https', hostname, port = 443, path, body = null, headers = {} }) {
        return new Promise(function (resolve, reject) {
            var options = {
                hostname: hostname,
                port: port,
                path: path,
                method: method,
                headers: headers
            };

            if (hostname.split(':')[1] != null) {
                options['port'] = hostname.split(':')[1];
                options['hostname'] = options['hostname'].replace(':' + options['port'], '');
            }

            var req = _connectivity[protocol].request(options, function (res) {
                var data = '';
                res.on('data', function (chunk) {
                    data += chunk;
                });

                res.on('error', function (err) {
                    reject(err);
                    return;
                });

                res.on('end', function () {
                    if (res.statusCode === 200) {
                        try {
                            resolve(JSON.parse(data));
                            return;
                        } catch (err) {
                            reject(err);
                            return;
                        }

                    } else {
                        reject('HTTP Error! ' + res.statusCode + ' ' + data.toString());
                        return;
                    }
                });
            });

            req.on('error', function (err) {
                reject(err);
                return;
            });

            if (body != null) {
                var reqBody = body;
                if(typeof reqBody !== 'string') {
                    reqBody = JSON.stringify(reqBody);
                }
                req.write(reqBody);
            }

            req.end();
        });
    }

    function timecodeToMs(durationTc, frames) {
        var ffs = frames;
        if (ffs == null) {
            ffs = 25;
        }
        var durationSplits = durationTc.split(':');
        var hh = Number(durationSplits[0]);
        var mm = Number(durationSplits[1]);
        var ss = Number(durationSplits[2]);
        var ff = Number(durationSplits[3]);
        return Number((1000 / ffs * ff) + (ss * 1000) + (mm * 60 * 1000) + (hh * 60 * 60 * 1000));
    }

    function msToTimecode(durationMs, frames) {
        var ffs = frames;
        if (ffs == null) {
            ffs = 25;
        }
        var hh = Math.trunc(durationMs / (1000 * 60 * 60));
        var mm = Math.trunc((durationMs / (1000 * 60)) % 60);
        var ss = Math.trunc((durationMs / 1000) % 60);
        var ff = Math.trunc((durationMs % 1000) / (1 / ffs * 1000));

        var timecode = '';
        timecode += hh.toString().padStart(2, '0') + ':';
        timecode += mm.toString().padStart(2, '0') + ':';
        timecode += ss.toString().padStart(2, '0') + ':';
        timecode += ff.toString().padStart(2, '0');

        return timecode;
    }

    function msToFrames(durationMs, frames) {
        var ffs = frames;
        if (ffs == null) {
            ffs = 25;
        }
        return Number((durationMs / 1000) * ffs);
    }

    function framesToMs(frames, fps) {
        var ffs = fps;
        if (ffs == null) {
            ffs = 25;
        }
        return Number((frames / ffs) * 1000);
    }

    function timestampToMs(timestamp) {
        var hh = Math.trunc(timestamp.split(':')[0]) * 60 * 60 * 1000;
        var mm = Math.trunc(timestamp.split(':')[1]) * 60 * 1000;
        var ss = Math.trunc(timestamp.split(':')[2].split('.')[0]) * 1000;
        var mmm = timestamp.split(':')[2].split('.')[1];
        return Number(hh) + Number(mm) + Number(ss) + Number(mmm);
    }

    function fromAirDateTimeToEpoch(time, ffps) {
        var fps = ffps;
        if (fps == null) {
            fps = 25;
        }
        var timeSplit = time.split('T');

        var date = timeSplit[0];
        var timing = timeSplit[1];
        var timingSplit = timing.split(':');

        var frames = timingSplit[3];
        var milliseconds = (frames / fps) * 1000;
        if (milliseconds === 1000) {
            milliseconds = 999;
        }

        var stringDate = date;
        stringDate += 'T' + timingSplit[0];
        stringDate += ':' + timingSplit[1];
        stringDate += ':' + timingSplit[2];
        stringDate += '.' + milliseconds + 'Z';

        var cleanDate = new Date(stringDate);
        return cleanDate.getTime();
    }

    return {
        performRequest: performRequest,
        timecodeToMs: timecodeToMs,
        timestampToMs: timestampToMs,
        msToTimecode: msToTimecode,
        msToFrames: msToFrames,
        framesToMs: framesToMs,
        fromAirDateTimeToEpoch: fromAirDateTimeToEpoch
    };
})();
