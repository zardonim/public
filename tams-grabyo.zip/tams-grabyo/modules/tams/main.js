module.exports = (function () {

    const { randomUUID } = require('crypto');
    const utilities = require('../common/utilities');
    const queryString = require('querystring');
    const awsClientS3 = require('@aws-sdk/client-s3');
    const awsRequestPresignerS3 = require('@aws-sdk/s3-request-presigner');
    const awsCredentialProviders = require('@aws-sdk/credential-providers');

    function create(logger) {
        return init(logger);
    }

    function init(logger) {
        var _logger;
        var _instanceId = randomUUID();
        var _accessTokenEndpoint;
        var _apiEndpoint;
        var _bearerToken;
        var _clientId;
        var _clientSecret;
        var _awsAccessKey;
        var _awsSecretAccessKey;
        var _awsSourceId;
        var _bucketId;
        var _region;

        if (logger != null) {
            _logger = logger;
        } else {
            _logger = {
                log: console.log
            };
        }

        function _getInstanceId() {
            return _instanceId;
        }

        function _setAccessTokenEndpoint(url) {
            _accessTokenEndpoint = {};
            _accessTokenEndpoint['protocol'] = url.split('://')[0];
            _accessTokenEndpoint['hostname'] = url.replace(_accessTokenEndpoint['protocol'] + '://', '').split('/')[0];
            _accessTokenEndpoint['hostname'] = _accessTokenEndpoint['hostname'].split(':')[0];
            _accessTokenEndpoint['port'] = _accessTokenEndpoint['hostname'].split(':')[1];
            _accessTokenEndpoint['path'] = url.replace(_accessTokenEndpoint['protocol'] + '://' + _accessTokenEndpoint['hostname'], '');
        }

        function _setApiEndpoint(url) {
            _apiEndpoint = {};
            _apiEndpoint['protocol'] = url.split('://')[0];
            _apiEndpoint['hostname'] = url.replace(_apiEndpoint['protocol'] + '://', '').split('/')[0];
            _apiEndpoint['hostname'] = _apiEndpoint['hostname'].split(':')[0];
            _apiEndpoint['port'] = _apiEndpoint['hostname'].split(':')[1];
            _apiEndpoint['path'] = url.replace(_apiEndpoint['protocol'] + '://' + _apiEndpoint['hostname'], '');
        }

        function _setAwsAccessKey(key) {
            _awsAccessKey = key;
        }

        function _setAwsSecretAccessKey(key) {
            _awsSecretAccessKey = key;
        }


        function _setSourceId(sourceId) {
            _awsSourceId = sourceId;
        }

        function _setBucketId(bucket) {
            _bucketId = bucket;
        }

        async function _getAccessToken() {
            var protocol = _accessTokenEndpoint['protocol'];
            var hostname = _accessTokenEndpoint['hostname'];
            var path = _accessTokenEndpoint['path'];
            var grantType = 'client_credentials';
            var scope = 'tams-api/read tams-api/write tams-api/delete';

            var data = queryString.stringify({
                client_id: _clientId,
                client_secret: _clientSecret,
                grant_type: grantType,
                scope: scope
            });

            var result = await utilities.performRequest({
                method: 'POST',
                protocol: protocol,
                hostname: hostname,
                path: path,
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: data
            });

            _bearerToken = result['access_token'];
        }

        function _setClientId(clientId) {
            _clientId = clientId;

        }

        function _setClientSecret(clientSecret) {
            _clientSecret = clientSecret;
        }

        function _setRegion(region) {
            _region = region;
        }

        async function _listFlows() {
            var token = await _getAccessToken();
            var result = await utilities.performRequest({
                method: 'GET',
                protocol: _apiEndpoint['protocol'],
                hostname: _apiEndpoint['hostname'],
                path: _apiEndpoint['path'] + '/flows',
                headers: { 'Authorization': 'Bearer ' + _bearerToken },
            });
            return result;
        }

        async function _getPresignManifestUrl() {
            var s3 = new awsClientS3.S3Client({
                region: _region,
                credentials: { accessKeyId: _awsAccessKey, secretAccessKey: _awsSecretAccessKey }
            });

            return awsRequestPresignerS3.getSignedUrl(s3, new awsClientS3.GetObjectCommand({ Bucket: _bucketId, Key: 'sources/' + _awsSourceId + '/manifest.m3u8' }), { expiresIn: 3600 * 7 });
        }

        return {
            getInstanceId: _getInstanceId,
            setAccessTokenEndpoint: _setAccessTokenEndpoint,
            setClientId: _setClientId,
            setClientSecret: _setClientSecret,
            setAwsAccessKey: _setAwsAccessKey,
            setAwsSecretAccessKey: _setAwsSecretAccessKey,
            setApiEndpoint: _setApiEndpoint,
            setSourceId: _setSourceId,
            setBucketId: _setBucketId,
            setRegion: _setRegion,
            listFlows: _listFlows,
            getPresignManifestUrl: _getPresignManifestUrl
        };
    }

    return {
        getInstance: create
    };
})();