module.exports = (function () {

    const { randomUUID } = require('crypto');
    const utilities = require('../common/utilities');
    const fs = require('fs');
    const constants = require('./constants');
    const EventEmitter = require('events');

    function create(logger) {
        return init(logger);
    }

    function init(logger) {
        var _logger;
        if (logger != null) {
            _logger = logger;
        } else {
            _logger = {
                log: console.log
            };
        }

        var _instanceId = randomUUID();
        var _schedule = [];
        var _observerInterval = null;
        var _emitter = new EventEmitter();
        var _lastEventScheduled;

        async function _loadScheduleFromAPI({ type, filters, options }) {
            var url = options['url'];
            var protocol = url.split('://')[0];
            var port = -1;
            switch (protocol) {
                case 'http':
                    port = 80;
                    break;

                case 'https':
                    port = 443;
                    break;
            }
            var hostname = url.replace(protocol + '://', '').split('/')[0];
            var path = url.replace(protocol + '://' + hostname, '');
            var opts = {
                method: 'GET',
                protocol: protocol,
                hostname: hostname,
                port: port,
                path: path
            };
            if (options['headers'] != null) {
                opts['headers'] = options['headers'];
            }
            var schedule = await utilities.performRequest(opts);
            fs.writeFileSync(constants.scheduler.localScheduleStorePath, JSON.stringify(schedule));
            _loadScheduleFromFile(type, constants.scheduler.localScheduleStorePath, filters);
        }

        function _loadScheduleFromFile(type, path, filters) {
            switch (type) {
                case 'ADC100':
                    var scheduling = fs.readFileSync(path);
                    scheduling = JSON.parse(scheduling);
                    for (var scheduleIndex = 0; scheduleIndex < scheduling.length; scheduleIndex++) {
                        var scheduleItem = scheduling[scheduleIndex];

                        var admitted = true;

                        for (var filter in filters) {
                            if (filters.hasOwnProperty(filter)) {
                                if (scheduleItem[filter] !== filters[filter]) {
                                    admitted = false;
                                    _logger.log('DEBUG', 'Filter with property', filter, 'not fulfilled! -> ', scheduleItem[filter], '!==', filters[filter]);
                                    break;
                                }
                            }
                        }

                        if (admitted) {
                            var durationMs = utilities.timecodeToMs(scheduleItem['Duration']);
                            var newItem = {
                                id: scheduleItem['AdcEventId'],
                                startTime: scheduleItem['OnAirDateTime'],
                                duration: scheduleItem['Duration'],
                                title: scheduleItem['Title'],
                                epoch: utilities.fromAirDateTimeToEpoch(scheduleItem['OnAirDateTime'])
                            };
                            if (durationMs >= constants.scheduler.minimumPrimaryEventsMilliseconds) {
                                newItem['type'] = 'primary';
                            } else {
                                newItem['type'] = 'secondary';
                            }
                            _insertIntoSchedule(newItem);
                        }
                    }
                    break;

                default:
                    _logger.log('WARN', 'No scheduler type has been properly intercepted!');
                    break;
            }
            _observeSchedule();
            _logger.log('Scheduler interface', _instanceId, 'properly instantiated!');
        }

        function _insertIntoSchedule(item) {
            var lowIndex = 0;
            var highIndex = _schedule.length;

            while (lowIndex < highIndex) {
                var midIndex = Math.floor((lowIndex + highIndex) / 2);

                if (_schedule[midIndex]['epoch'] < item['epoch']) {
                    lowIndex = midIndex + 1;
                } else {
                    highIndex = midIndex;
                }
            }

            _schedule.splice(lowIndex, 0, item);
        }

        function _observeSchedule() {
            var now = Date.now();
            for (var indexSchedule = 0; indexSchedule < _schedule.length; indexSchedule++) {
                var item = _schedule[indexSchedule];
                if (((item['epoch'] - now) > 0) && ((item['epoch'] - now) < constants.scheduler.deltaOnAirMilliseconds)) {
                    if (_lastEventScheduled !== item['id']) {
                        _logger.log('DEBUG', 'The event', item['title'], 'is going On Air!', item['startTime']);
                        _emitter.emit('nextScheduledEvent', item);
                        _lastEventScheduled = item['id'];
                    }
                    break;
                }
            }
            if (_observerInterval != null) {
                clearTimeout(_observerInterval);
            }
            _observerInterval = setTimeout(function () { _observeSchedule() }, constants.scheduler.observingStatusMilliseconds);
        }

        function _getNextScheduledEvent() {
            var now = Date.now();
            var event = null;
            for (var indexSchedule = 0; indexSchedule < _schedule.length; indexSchedule++) {
                var item = _schedule[indexSchedule];
                if ((item['epoch'] - now) > 0) {
                    event = item;
                    break;
                }
            }
            return event;
        }

        function _getSchedule() {
            fs.writeFileSync('/tmp/schedule.json', JSON.stringify(_schedule));
            return _schedule;
        }

        function _getInstanceId() {
            return _instanceId;
        }

        function _getEventEmitter() {
            return _emitter;
        }

        return {
            getInstanceId: _getInstanceId,
            getSchedule: _getSchedule,
            loadScheduleFromFile: _loadScheduleFromFile,
            loadScheduleFromAPI: _loadScheduleFromAPI,
            getNextScheduledEvent: _getNextScheduledEvent,
            getObserver: _getEventEmitter
        };
    }

    return {
        getInstance: create
    };
})();