var config = {};

config.scheduler = {};
config.scheduler.observingStatusMilliseconds = 1500;
config.scheduler.deltaOnAirMilliseconds = 10000;
config.scheduler.minimumPrimaryEventsMilliseconds = 5 * 60 * 1000;
config.scheduler.localScheduleStorePath = '/tmp/schedule.json';

module.exports = config;