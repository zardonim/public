module.exports = (function () {

    const { randomUUID } = require('crypto');
    const utilities = require('../common/utilities');

    function create(logger) {
        return init(logger);
    }

    function init(logger) {
        var _logger;
        if (logger != null) {
            _logger = logger;
        } else {
            _logger = {
                log: console.log
            };
        }

        var _instanceId = randomUUID();
        var _username;
        var _password;
        var _endpoint;
        var _token;

        function _getInstanceId() {
            return _instanceId;
        }

        function _setUsername(username) {
            _username = username;
            _setToken();
        }

        function _setPassword(password) {
            _password = password;
            _setToken();
        }

        function _setToken() {
            if(_username != null && _password != null) {
                _token = Buffer.from(_username + ':' + _password).toString('base64');
            }
        }

        function _setEndpoint(url) {
            _endpoint = {};
            _endpoint['protocol'] = url.split('://')[0];
            _endpoint['hostname'] = url.replace(_endpoint['protocol'] + '://', '').split('/')[0];
            _endpoint['hostname'] = _endpoint['hostname'].split(':')[0];
            _endpoint['port'] = _endpoint['hostname'].split(':')[1];
            _endpoint['path'] = url.replace(_endpoint['protocol'] + '://' + _endpoint['hostname'], '');
        }

        async function _getModule(moduleId) {
            var result = await utilities.performRequest({
                method:'GET',
                protocol:  _endpoint['protocol'],
                hostname:  _endpoint['hostname'],
                path: _endpoint['path'] + '/module/' + moduleId,
                headers: {'Authorization': 'Basic ' + _token}
            });
            return result;
        }

        return {
            setUsername: _setUsername,
            setPassword: _setPassword,
            getModule: _getModule,
            setEndpoint: _setEndpoint,
            getInstanceId: _getInstanceId
        };
    }

    return {
        getInstance: create
    };
})();