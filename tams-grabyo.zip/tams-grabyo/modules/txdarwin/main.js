module.exports = (function () {

    const { randomUUID } = require('crypto');
    const utilities = require('../common/utilities');

    function create(logger) {
        return init(logger);
    }

    function init(logger) {
        var _logger;
        if (logger != null) {
            _logger = logger;
        } else {
            _logger = {
                log: console.log
            };
        }

        var _instanceId = randomUUID();
        var _username;
        var _password;
        var _endpoint;
        var _token;

        function _getInstanceId() {
            return _instanceId;
        }

        function _setUsername(username) {
            _username = username;
            _setToken();
        }

        function _setPassword(password) {
            _password = password;
            _setToken();
        }

        function _setToken() {
            if (_username != null && _password != null) {
                _token = Buffer.from(_username + ':' + _password).toString('base64');
            }
        }

        function _setEndpoint(url) {
            _endpoint = {};
            _endpoint['protocol'] = url.split('://')[0];
            _endpoint['hostname'] = url.replace(_endpoint['protocol'] + '://', '').split('/')[0];
            _endpoint['port'] = _endpoint['hostname'].split(':')[1];
            _endpoint['hostname'] = _endpoint['hostname'].split(':')[0];
            _endpoint['path'] = url.replace(_endpoint['protocol'] + '://' + _endpoint['hostname'], '');
            _endpoint['path'] = _endpoint['path'].replace(':' + _endpoint['port'], '');
        }

        async function _getModule(moduleId) {
            var result = await utilities.performRequest({
                method: 'GET',
                protocol: _endpoint['protocol'],
                hostname: _endpoint['hostname'],
                path: _endpoint['path'] + '/module/' + moduleId,
                headers: { 'Authorization': 'Basic ' + _token },
                port: _endpoint['port']
            });
            return result;
        }

        async function _startModule(moduleId) {
            var dataModule = await _getModule(moduleId);
            if (!dataModule['data']['options']['paused']) {
                _logger.log('The module is already started!');
            } else {
                var patchModule = {
                    id: dataModule['data']['id'],
                    type: dataModule['data']['type'],
                    version: dataModule['data']['version'],
                    name: dataModule['data']['name'],
                    options: {
                        paused: false
                    }
                };
                await utilities.performRequest({
                    method: 'PUT',
                    protocol: _endpoint['protocol'],
                    hostname: _endpoint['hostname'],
                    path: _endpoint['path'] + '/module/' + moduleId,
                    headers: { 'Authorization': 'Basic ' + _token },
                    port: _endpoint['port'],
                    body: patchModule
                });
                dataModule = await _getModule(moduleId);
                if (!dataModule['data']['options']['paused']) {
                    _logger.log('The module has been properly started!');
                    return true;
                } else {
                    _logger.log('Something went wrong!');
                    return false;
                }
            }
        }

        async function _stopModule(moduleId) {
            var dataModule = await _getModule(moduleId);
            if (dataModule['data']['options']['paused']) {
                _logger.log('The module is already stopped!');
            } else {
                var patchModule = {
                    id: dataModule['data']['id'],
                    type: dataModule['data']['type'],
                    version: dataModule['data']['version'],
                    name: dataModule['data']['name'],
                    options: {
                        paused: true
                    }
                };
                await utilities.performRequest({
                    method: 'PUT',
                    protocol: _endpoint['protocol'],
                    hostname: _endpoint['hostname'],
                    path: _endpoint['path'] + '/module/' + moduleId,
                    headers: { 'Authorization': 'Basic ' + _token },
                    port: _endpoint['port'],
                    body: patchModule
                });
                dataModule = await _getModule(moduleId);
                if (dataModule['data']['options']['paused']) {
                    _logger.log('The module has been properly stopped!');
                    return true;
                } else {
                    _logger.log('Something went wrong!');
                    return false;
                }
            }
        }

        async function _isModulePaused(moduleId) {
            var dataModule = await _getModule(moduleId);
            return dataModule['data']['options']['paused'];
        }

        return {
            setUsername: _setUsername,
            setPassword: _setPassword,
            getModule: _getModule,
            setEndpoint: _setEndpoint,
            getInstanceId: _getInstanceId,
            startModule: _startModule,
            stopModule: _stopModule,
            isModulePaused: _isModulePaused
        };
    }

    return {
        getInstance: create
    };
})();