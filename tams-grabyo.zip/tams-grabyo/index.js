const log = require('./modules/logger/main');
const grabyo = require('./modules/grabyo/main');
const utilities = require('./modules/common/utilities');
const scheduler = require('./modules/scheduler/main');
const tams = require('./modules/tams/main');
const txdarwin = require('./modules/txdarwin/main');


main();

async function main() {
    var logger = log.create('debug');

    // var schedulerInterface = scheduler.getInstance(logger);

    /*await schedulerInterface.loadScheduleFromAPI({
        type: 'ADC100', filters: { EventType: 0 }, options: {
            url: 'http://10.64.10.222:8080/playlist/SYS1M/8'
        }
    });*/

    //    schedulerInterface.loadScheduleFromFile('ADC100', '/Users/zardonim/local/Projects/internal/app-utilities/tams-grabyo/modules/scheduler/fake.json', {'EventType': 0})

    //  var nextEvent = schedulerInterface.getNextScheduledEvent();
    //logger.log('Next scheduled event ->', nextEvent);
    //var scheduleObserver = schedulerInterface.getObserver();

    //scheduleObserver.on('nextScheduledEvent', function (event) {
    //   logger.log('Next event which is going On Air:', event);
    //});

    /*var tamsInterface = tams.getInstance(logger);

    tamsInterface.setAccessTokenEndpoint('https://233773012773-tams-0a6b445ead83.auth.eu-west-2.amazoncognito.com/oauth2/token');
    tamsInterface.setApiEndpoint('https://fg3pqohlt8.execute-api.eu-west-2.amazonaws.com/Prod');
    tamsInterface.setClientId('47r8ls9fike857bfpdtoio20m7');
    tamsInterface.setClientSecret('16mnclvv4q18ug8fiqgf7ftjpqr3ndq4dv741t4b0tb4hu6v7u9o');

    tamsInterface.setBucketId('arn:aws:s3-object-lambda:eu-west-2:233773012773:accesspoint/tams-tools-v31');
    tamsInterface.setAwsAccessKey('AKIATM3PVC4S24RXXX5F');
    tamsInterface.setAwsSecretAccessKey('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');
    tamsInterface.setSourceId('483c8cc5-7ef4-444b-9764-729ecd5565aa');
    tamsInterface.setRegion('eu-west-2');

    var presignedUrl = await tamsInterface.getPresignManifestUrl();

    var grabyoInterface = grabyo.getInstance(logger);
    var grabyoObserver = grabyoInterface.getObserver();

    grabyoInterface.setUrl('https://oapi.grabyo.com');
    grabyoInterface.setToken('3kuFHXCjgp3fGpur2XtcA4uexgHs9jKsaFk43PF3');
    grabyoInterface.setStreamId('Od8DKIsQBZN');

    await grabyoInterface.startRecording();
    await grabyoInterface.setStreamSource(presignedUrl);

    grabyoObserver.on('streamStatusChanged', async function (status) {
        if ('ONLINE' === status.toUpperCase()) {
            setTimeout(async function () { await grabyoInterface.stopRecording(); }, 65000);
        }
    });

    await grabyoInterface.startRecording();*/

    var txdarwinInterface = txdarwin.getInstance(logger);

    txdarwinInterface.setUsername('admin');
    txdarwinInterface.setPassword('admin');
    txdarwinInterface.setEndpoint('https://10.52.33.85:8002');

    var result = await txdarwinInterface.getModule('mod-b42788d0-a7cc-4f34-ba4c-a0985ef2fa33');
    console.log(result)
    
}
