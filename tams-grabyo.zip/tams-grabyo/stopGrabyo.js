process.env.NODE_TLS_REJECT_UNAUTHORIZED = 0;

const grabyo = require('./modules/grabyo/main');
const log = require('./modules/logger/main');

//=====
main();
//=====

async function main() {
    var logger = log.create('info');
    var grabyoInterface = grabyo.getInstance(logger);
    var grabyoObserver = grabyoInterface.getObserver();

    grabyoInterface.setUrl('https://oapi.grabyo.com');
    grabyoInterface.setToken('3kuFHXCjgp3fGpur2XtcA4uexgHs9jKsaFk43PF3');
    grabyoInterface.setStreamId('Od8DKIsQBZN');
    await grabyoInterface.stopRecording();

    grabyoObserver.on('streamStatusChanged', async function (status) {
        logger.log('Grabyo change its status. Status is', status);
    });

}